﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zombie_Shootout_Game
{
    public partial class GameOver : Form
    {
        public GameOver()
        {
            InitializeComponent();
        }

        private void Yes_btn_Click(object sender, EventArgs e)
        {
            Main_Menu nextlevel = new Main_Menu();
            nextlevel.Show();

            Close();
        }

        private void No_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
