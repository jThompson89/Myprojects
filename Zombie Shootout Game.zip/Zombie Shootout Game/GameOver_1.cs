﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Zombie_Shootout_Game
{
    public partial class GameOver_1 : Form
    {

        public GameOver_1()
        {
            InitializeComponent();
        }

        private void Yes_btn_Click(object sender, EventArgs e)
        {
            Main_Menu nextlevel = new Main_Menu();
            nextlevel.Show();

            Close();
        }

        private void No_btn_Click(object sender, EventArgs e)
        {

            Application.Exit();
        }

        private void save_btn_Click(object sender, EventArgs e)
        {

        }
    }
}
