﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace Zombie_Shootout_Game
{
    internal class Shotgun
    {
        public string direction;
        public int shotgunLeft;
        public int shotgunTop;
        private int speed = 20;

        public int shotgun2Left;
        public int shotgun2Top;


        public int shotgun3Left;
        public int shotgun3Top;

        private PictureBox shotgun = new PictureBox();
        private Timer shotgunTimer = new Timer();

        private PictureBox shotgun2 = new PictureBox();
        private Timer shotgun2Timer = new Timer();

        private PictureBox shotgun3 = new PictureBox();
        private Timer shotgun3Timer = new Timer();


        WindowsMediaPlayer player = new WindowsMediaPlayer();

        public object transform { get; internal set; }

        public void MakeShotgun(Form form)
        {

            shotgun.Image = Properties.Resources.shotgunbulletup;
            shotgun.Size = new Size(100, 100);
            shotgun.Tag = "shotgun";
            shotgun.Left = shotgunLeft;
            shotgun.Top = shotgunTop;        
            shotgun.BringToFront();

            form.Controls.Add(shotgun);        

            shotgunTimer.Interval = speed;
            shotgunTimer.Tick += new EventHandler(ShotgunTimerEvent);
            shotgunTimer.Start();

           
        }

        public void DoubleShot(Form form)
        {
            shotgun.Image = Properties.Resources.shotgunbulletup;
            shotgun.Size = new Size(100, 100);
            shotgun.Tag = "shotgun";
            shotgun.Left = shotgunLeft;
            shotgun.Top = shotgunTop;       
            shotgun.BringToFront();

            form.Controls.Add(shotgun);

            shotgunTimer.Interval = speed;
            shotgunTimer.Tick += new EventHandler(ShotgunTimerEvent);
            shotgunTimer.Start();

            shotgun2.Image = Properties.Resources.shotgunbulletup;
            shotgun2.Size = new Size(100, 100);
            shotgun2.Tag = "shotgun";
            shotgun2.Left = shotgunLeft;
            shotgun2.Top = shotgunTop;          
            shotgun2.BringToFront();

            form.Controls.Add(shotgun);

            shotgun2Timer.Interval = speed;
            shotgun2Timer.Tick += new EventHandler(DoubleShotTimerEvent);
            shotgun2Timer.Start();
        }

        public void TripleBarrel(Form form)
        {
            shotgun.Image = Properties.Resources.shotgunbulletup;
            shotgun.Size = new Size(100, 100);
            shotgun.Tag = "shotgun";
            shotgun.Left = shotgunLeft;
            shotgun.Top = shotgunTop;          
            shotgun.BringToFront();

            form.Controls.Add(shotgun);

            shotgunTimer.Interval = speed;
            shotgunTimer.Tick += new EventHandler(ShotgunTimerEvent);
            shotgunTimer.Start();

            shotgun2.Image = Properties.Resources.shotgunbulletup;
            shotgun2.Size = new Size(100, 100);
            shotgun2.Tag = "shotgun";
            shotgun2.Left = shotgunLeft;
            shotgun2.Top = shotgunTop;          
            shotgun2.BringToFront();

            form.Controls.Add(shotgun);

            shotgun2Timer.Interval = speed;
            shotgun2Timer.Tick += new EventHandler(DoubleShotTimerEvent);
            shotgun2Timer.Start();


            shotgun3.Image = Properties.Resources.shotgunbulletup;
            shotgun3.Size = new Size(100, 100);
            shotgun3.Tag = "shotgun";
            shotgun3.Left = shotgunLeft;
            shotgun3.Top = shotgunTop;
            shotgun3.BringToFront();

            form.Controls.Add(shotgun);

            shotgun3Timer.Interval = speed;
            shotgun3Timer.Tick += new EventHandler(TripleBarrelTImerEvent);
            shotgun3Timer.Start();
        }

        private void Shotgunsound(Form form)
        {
            player.URL = "C:\\Users\\AMStudent\\source\\repos\\Zombie Shootout Game\\Zombie Shootout Game\\shotgun_sound.mp3";
            player.controls.play();
            player.URL = "C:\\Users\\AMStudent\\source\\repos\\Zombie Shootout Game\\Zombie Shootout Game\\shotgun_sound.mp3";
            player.controls.play();
        }


        private void ShotgunTimerEvent(object sender, EventArgs e)
        {

            if (direction == "left")
            {
                shotgun.Left -= speed;
                shotgun.Image = Properties.Resources.shotgunbulletleft;

            }

            if (direction == "right")
            {
                shotgun.Left += speed; shotgun.Image = Properties.Resources.shotgunbulletright;

            }

            if (direction == "up")
            {
                shotgun.Top -= speed; shotgun.Image = Properties.Resources.shotgunbulletup;

            }

            if (direction == "down")
            {
                shotgun.Top += speed; shotgun.Image = Properties.Resources.shotgunbulletdown;

            }



            if (shotgun.Left < 10 || shotgun.Left > 1123 || shotgun.Top < 10 || shotgun.Top > 860)
            {
                shotgunTimer.Stop();
                shotgunTimer.Dispose();
                shotgun.Dispose();
                shotgunTimer = null;
                shotgun = null;
            }
        }

        private void DoubleShotTimerEvent(object sender, EventArgs e)
        {
            if (direction == "left")
            {
                shotgun.Left -= speed;
                shotgun.Image = Properties.Resources.shotgunbulletleft;

            }

            if (direction == "right")
            {
                shotgun.Left += speed;
                shotgun.Image = Properties.Resources.shotgunbulletright;

            }

            if (direction == "up")
            {
                shotgun.Top -= speed;
                shotgun.Image = Properties.Resources.shotgunbulletup;

            }

            if (direction == "down")
            {
                shotgun.Top += speed;
                shotgun.Image = Properties.Resources.shotgunbulletdown;

            }



            if (shotgun.Left < 10 || shotgun.Left > 1123 || shotgun.Top < 10 || shotgun.Top > 860)
            {
                shotgunTimer.Stop();
                shotgunTimer.Dispose();
                shotgun.Dispose();
                shotgunTimer = null;
                shotgun = null;
            }

            if (direction == "left")
            {
                shotgun2.Left -= speed;
                shotgun2.Image = Properties.Resources.shotgunbulletleft;

            }

            if (direction == "right")
            {
                shotgun2.Left += speed;
                shotgun2.Image = Properties.Resources.shotgunbulletright;

            }

            if (direction == "up")
            {
                shotgun2.Top -= speed;
                shotgun2.Image = Properties.Resources.shotgunbulletup;

            }

            if (direction == "down")
            {
                shotgun2.Top += speed;
                shotgun2.Image = Properties.Resources.shotgunbulletdown;

            }



            if (shotgun2.Left < 10 || shotgun2.Left > 1123 || shotgun2.Top < 10 || shotgun2.Top > 860)
            {
                shotgun2Timer.Stop();
                shotgun2Timer.Dispose();
                shotgun2.Dispose();
                shotgun2Timer = null;
                shotgun2 = null;
            }
        }

        private void TripleBarrelTImerEvent(object sender, EventArgs e)
        {
            if (direction == "left")
            {
                shotgun.Left -= speed;
                shotgun.Image = Properties.Resources.shotgunbulletleft;

            }

            if (direction == "right")
            {
                shotgun.Left += speed;
                shotgun.Image = Properties.Resources.shotgunbulletright;

            }

            if (direction == "up")
            {
                shotgun.Top -= speed;
                shotgun.Image = Properties.Resources.shotgunbulletup;

            }

            if (direction == "down")
            {
                shotgun.Top += speed;
                shotgun.Image = Properties.Resources.shotgunbulletdown;

            }



            if (shotgun.Left < 10 || shotgun.Left > 1123 || shotgun.Top < 10 || shotgun.Top > 860)
            {
                shotgunTimer.Stop();
                shotgunTimer.Dispose();
                shotgun.Dispose();
                shotgunTimer = null;
                shotgun = null;
            }

            if (direction == "left")
            {
                shotgun2.Left -= speed;
                shotgun2.Image = Properties.Resources.shotgunbulletleft;

            }

            if (direction == "right")
            {
                shotgun2.Left += speed;
                shotgun2.Image = Properties.Resources.shotgunbulletright;

            }

            if (direction == "up")
            {
                shotgun2.Top -= speed;
                shotgun2.Image = Properties.Resources.shotgunbulletup;

            }

            if (direction == "down")
            {
                shotgun2.Top += speed;
                shotgun2.Image = Properties.Resources.shotgunbulletdown;

            }



            if (shotgun2.Left < 10 || shotgun2.Left > 1123 || shotgun2.Top < 10 || shotgun2.Top > 860)
            {
                shotgun2Timer.Stop();
                shotgun2Timer.Dispose();
                shotgun2.Dispose();
                shotgun2Timer = null;
                shotgun2 = null;
            }

            if (direction == "left")
            {
                shotgun3.Left -= speed;
                shotgun3.Image = Properties.Resources.shotgunbulletleft;

            }

            if (direction == "right")
            {
                shotgun3.Left += speed;
                shotgun3.Image = Properties.Resources.shotgunbulletright;

            }

            if (direction == "up")
            {
                shotgun3.Top -= speed;
                shotgun3.Image = Properties.Resources.shotgunbulletup;

            }

            if (direction == "down")
            {
                shotgun3.Top += speed;
                shotgun3.Image = Properties.Resources.shotgunbulletdown;

            }



            if (shotgun3.Left < 10 || shotgun3.Left > 1123 || shotgun3.Top < 10 || shotgun3.Top > 860)
            {
                shotgun3Timer.Stop();
                shotgun3Timer.Dispose();
                shotgun3.Dispose();
                shotgun3Timer = null;
                shotgun3 = null;
            }
        }

        
    }
}
