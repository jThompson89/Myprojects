﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace Zombie_Shootout_Game
{
    internal class DoubleShot
    {
        public string direction;
        public int bulletLeft;
        public int bulletTop;

        public int bulletLeft2;
        public int bulletTop2;
        private int speed = 20;

        private PictureBox bullet = new PictureBox();
        private Timer bulletTimer = new Timer();

        private PictureBox bullet2 = new PictureBox();
        private Timer bulletTimer2 = new Timer();

        WindowsMediaPlayer player = new WindowsMediaPlayer();

        public void MakeDoubleBullet(Form form)
        {

            bullet.Image = Properties.Resources.shotLarge;
            bullet.Size = new Size(100, 100);
            bullet.Tag = "bullet";
            bullet.Left = bulletLeft;
            bullet.Top = bulletTop;
            bullet.BringToFront();

            form.Controls.Add(bullet);

            bullet2.Image = Properties.Resources.shotLarge;
            bullet2.Size = new Size(100, 100);
            bullet2.Tag = "doubleshot";
            bullet2.Left = bulletLeft;
            bullet2.Top = bulletTop;
            bullet2.BringToFront();

            form.Controls.Add(bullet);


            bulletTimer.Interval = speed;
            bulletTimer.Tick += new EventHandler(DoubleBulletTimerEvent);
            bulletTimer.Start();
        }

        private void Bulletsound(Form form)
        {
            player.URL = "C:\\Users\\AMStudent\\source\\repos\\Top Down zombie shooting game\\Top Down zombie shooting game\\Resources\\gun_sound.mp3";
            player.controls.play();
        }



        private void DoubleBulletTimerEvent(object sender, EventArgs e)
        {

            if (direction == "left")
            {
                bullet.Left -= speed;
                bullet.Image = Properties.Resources.shotLargeleft;

            }

            if (direction == "right")
            {
                bullet.Left += speed;
                bullet.Image = Properties.Resources.shotLargeright;
            }

            if (direction == "up")
            {
                bullet.Top -= speed;
                bullet.Image = Properties.Resources.shotLarge;

            }

            if (direction == "down")
            {
                bullet.Top += speed;
                bullet.Image = Properties.Resources.shotLargedown;

            }



            if (bullet.Left < 10 || bullet.Left > 1123 || bullet.Top < 10 || bullet.Top > 860)
            {
                bulletTimer.Stop();
                bulletTimer.Dispose();
                bullet.Dispose();
                bulletTimer = null;
                bullet = null;
            }
        }
    }

}
