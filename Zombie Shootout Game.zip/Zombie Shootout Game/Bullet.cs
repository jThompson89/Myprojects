﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Zombie_Shootout_Game
{
    internal class Bullet
    {

        public string direction;
        public int bulletLeft;
        public int bulletTop;

        public int bulletLeft2;
        public int bulletTop2;

        public int bulletLeft3;
        public int bulletTop3;


        private int speed = 20;
        private int speed2 = 10;
        private PictureBox bullet = new PictureBox();
        private Timer bulletTimer = new Timer();

        private PictureBox bullet2 = new PictureBox();
        private Timer bulletTimer2 = new Timer();

        private PictureBox bullet3 = new PictureBox();
        private Timer bulletTimer3 = new Timer();

        List<PictureBox> bulletList = new List<PictureBox>();


        WindowsMediaPlayer player = new WindowsMediaPlayer();

        public void MakeBullet(Form form)
        {

            bullet.Image = Properties.Resources.shotThin;           
            bullet.Size = new Size(100,100);
            bullet.Tag = "bullet";
            bullet.Left = bulletLeft;
            bullet.Top = bulletTop;
            bullet.BringToFront();

            form.Controls.Add(bullet);


            bulletTimer.Interval = speed;
            bulletTimer.Tick += new EventHandler(BulletTimerEvent);
            bulletTimer.Start();
        }

        public void DoubleBullet(Form form)
        {

            
            bullet.Size = new Size(100, 100);
            bullet.Image = Properties.Resources.shotThin;
            bullet.Tag = "bullet";
            bullet.Left = bulletLeft;
            bullet.Top = bulletTop;
            bullet.BringToFront();


            form.Controls.Add(bullet);

            bullet2.Size = new Size(100, 100);
            bullet2.Image = Properties.Resources.shotThin;
            bullet2.Tag = "bullet";
            bullet2.Left = bulletLeft;
            bullet2.Top = bulletTop;
            bullet2.BringToFront();

            form.Controls.Add(bullet2);


            bulletTimer2.Interval = speed2;
            bulletTimer2.Tick += new EventHandler(DoubleBulletTimerEvent);
            bulletTimer2.Start();

          
        }

        public void TripleBullet(Form form)
        {
           
            bullet.Image = Properties.Resources.shotThin;
            bullet.Size = new Size(100, 100);
            bullet.Tag = "bullet";
            bullet.Left = bulletLeft;
            bullet.Top = bulletTop;
            bullet.BringToFront();


            form.Controls.Add(bullet);

            bullet2.Image = Properties.Resources.shotThin;
            bullet2.Size = new Size(100, 100);
            bullet2.Tag = "bullet2";
            bullet2.Left = bulletLeft;
            bullet2.Top = bulletTop;
            bullet2.BringToFront();

            form.Controls.Add(bullet2);

            bullet3.Size = new Size(100, 100);
            bullet3.Image = Properties.Resources.shotThin;
            bullet3.Tag = "bullet3";
            bullet3.Left = bulletLeft;
            bullet3.Top = bulletTop;
            bullet3.BringToFront();


            form.Controls.Add(bullet3);


            bulletTimer2.Interval = speed2;
            bulletTimer2.Tick += new EventHandler(TripleBulletTimerEvent);
            bulletTimer2.Start();
        }


        private void Bulletsound(Form form)
        {
            player.URL = "C:\\Users\\AMStudent\\source\\repos\\Top Down zombie shooting game\\Top Down zombie shooting game\\Resources\\gun_sound.mp3";
            player.controls.play();
        }



        private void BulletTimerEvent(object sender, EventArgs e)
        {

            if (direction == "left")
            {
                bullet.Left -= speed;
                bullet.Image = Properties.Resources.shotThinleft;

            }

            if (direction == "right")
            {
                bullet.Left += speed;
                bullet.Image = Properties.Resources.shotThinright;
            }

            if (direction == "up")
            {
                bullet.Top -= speed;
                bullet.Image = Properties.Resources.shotThin;

            }

            if (direction == "down")
            {
                bullet.Top += speed;
                bullet.Image = Properties.Resources.shotThindown;

            }



            if (bullet.Left < 10 || bullet.Left > 1123 || bullet.Top < 10 || bullet.Top > 860)
            {
                bulletTimer.Stop();
                bulletTimer.Dispose();
                bullet.Dispose();
                bulletTimer = null;
                bullet = null;
            }
        }

        private void DoubleBulletTimerEvent(object sender, EventArgs e)
        {

            if (direction == "left")
            {
                bullet.Left -= speed;
                bullet.Image = Properties.Resources.shotLargeleft;

            }

            if (direction == "right")
            {
                bullet.Left += speed;
                bullet.Image = Properties.Resources.shotLargeright;

            }

            if (direction == "up")
            {
                bullet.Top -= speed;
                bullet.Image = Properties.Resources.shotLarge;

            }

            if (direction == "down")
            {
                bullet.Top += speed;
                bullet.Image = Properties.Resources.shotLargedown;

            }


            if (bullet.Left < 10 || bullet.Left > 1123 || bullet.Top < 10 || bullet.Top > 860)
            {
                bulletTimer.Stop();
                bulletTimer.Dispose();
                bullet.Dispose();
                bulletTimer = null;
                bullet = null;
            }

            if (direction == "left")
            {
                bullet2.Left += speed;
                bullet2.Image = Properties.Resources.shotLargeleft;

            }

            if (direction == "right")
            {
                bullet2.Left -= speed;
                bullet2.Image = Properties.Resources.shotLargeright;

            }

            if (direction == "up")
            {
                bullet2.Top += speed;
                bullet2.Image = Properties.Resources.shotLarge;

            }

            if (direction == "down")
            {
                bullet2.Top -= speed;
                bullet2.Image = Properties.Resources.shotLargedown;

            }



            if (bullet2.Left < 10 || bullet2.Left > 1123 || bullet2.Top < 10 || bullet2.Top > 860)
            {
                bulletTimer2.Stop();
                bulletTimer2.Dispose();
                bullet2.Dispose();
                bulletTimer2 = null;
                bullet2 = null;
            }
        }

        private void TripleBulletTimerEvent(object sender, EventArgs e)
        {

            if (direction == "left")
            {
                bullet.Left -= speed;
                bullet.Image = Properties.Resources.shotOrangeleft;

            }

            if (direction == "right")
            {
                bullet.Left += speed;
                bullet.Image = Properties.Resources.shotOrangeright;

            }

            if (direction == "up")
            {
                bullet.Top -= speed;
                bullet.Image = Properties.Resources.shotOrange;

            }

            if (direction == "down")
            {
                bullet.Top += speed;
                bullet.Image = Properties.Resources.shotOrangedown;

            }


            if (bullet.Left < 10 || bullet.Left > 1123 || bullet.Top < 10 || bullet.Top > 860)
            {
                bulletTimer.Stop();
                bulletTimer.Dispose();
                bullet.Dispose();
                bulletTimer = null;
                bullet = null;
            }

            if (direction == "left")
            {
                bullet2.Left += speed;
                bullet2.Image = Properties.Resources.shotOrangeleft;

            }

            if (direction == "right")
            {
                bullet2.Left -= speed;
                bullet2.Image = Properties.Resources.shotOrangeright;

            }

            if (direction == "up")
            {
                bullet2.Top += speed;
                bullet2.Image = Properties.Resources.shotOrange;

            }

            if (direction == "down")
            {
                bullet2.Top -= speed;
                bullet2.Image = Properties.Resources.shotOrangedown;

            }


            if (bullet2.Left < 10 || bullet2.Left > 1123 || bullet2.Top < 10 || bullet2.Top > 860)
            {
                bulletTimer3.Stop();
                bulletTimer3.Dispose();
                bullet3.Dispose();
                bulletTimer3 = null;
                bullet3 = null;
            }

            if (direction == "left")
            {
                bullet3.Left += speed;
                bullet3.Image = Properties.Resources.shotOrangeleft;

            }

            if (direction == "right")
            {
                bullet3.Left -= speed;
                bullet3.Image = Properties.Resources.shotOrangeright;

            }

            if (direction == "up")
            {
                bullet3.Top += speed;
                bullet3.Image = Properties.Resources.shotOrange;

            }

            if (direction == "down")
            {
                bullet3.Top -= speed;
                bullet3.Image = Properties.Resources.shotOrangedown;

            }



            if (bullet3.Left < 10 || bullet3.Left > 1123 || bullet3.Top < 10 || bullet3.Top > 860)
            {
                bulletTimer3.Stop();
                bulletTimer3.Dispose();
                bullet3.Dispose();
                bulletTimer3 = null;
                bullet3 = null;
            }
        }

    }
}
