﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zombie_Shootout_Game
{
    public partial class Level_2_Complete : Form
    {
        public Level_2_Complete()
        {
            InitializeComponent();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            Level_3 nextlevel = new Level_3();
            nextlevel.Show();

            Close();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
