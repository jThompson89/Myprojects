﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace Zombie_Shootout_Game
{
    public partial class Main_Menu : Form
    {
        WindowsMediaPlayer player = new WindowsMediaPlayer();
        public Main_Menu()
        {
            InitializeComponent();
            player.URL = "C:\\Users\\AMStudent\\source\\repos\\Zombie Shootout Game\\Zombie Shootout Game\\Resources\\mainmusic.mp3";

        }

        private void Highscore()
        {
        
        }

        private void LoadGame(object sender, EventArgs e)
        {
            Level_1: Form gameWindow = new Level_1();

            gameWindow.Show();
        }

        private void Exitgame_btn(object sender, EventArgs e)
        {
            
        }

        private void ExitGame_btn(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Main_Menu_Load(object sender, EventArgs e)
        {

        }
    }
}
