﻿namespace Zombie_Shootout_Game
{
    partial class Level_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Ammo = new System.Windows.Forms.Label();
            this.Kills = new System.Windows.Forms.Label();
            this.Stage_2 = new System.Windows.Forms.Label();
            this.Health = new System.Windows.Forms.Label();
            this.healthBar = new System.Windows.Forms.ProgressBar();
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            this.shooter = new System.Windows.Forms.PictureBox();
            this.HighScore = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.shooter)).BeginInit();
            this.SuspendLayout();
            // 
            // Ammo
            // 
            this.Ammo.AutoSize = true;
            this.Ammo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ammo.Location = new System.Drawing.Point(12, 20);
            this.Ammo.Name = "Ammo";
            this.Ammo.Size = new System.Drawing.Size(103, 25);
            this.Ammo.TabIndex = 2;
            this.Ammo.Text = "Ammo: 0";
            // 
            // Kills
            // 
            this.Kills.AutoSize = true;
            this.Kills.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Kills.Location = new System.Drawing.Point(145, 20);
            this.Kills.Name = "Kills";
            this.Kills.Size = new System.Drawing.Size(84, 25);
            this.Kills.TabIndex = 5;
            this.Kills.Text = "Kills: 0";
            // 
            // Stage_2
            // 
            this.Stage_2.AutoSize = true;
            this.Stage_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Stage_2.Location = new System.Drawing.Point(501, 20);
            this.Stage_2.Name = "Stage_2";
            this.Stage_2.Size = new System.Drawing.Size(100, 25);
            this.Stage_2.TabIndex = 6;
            this.Stage_2.Text = "Stage: 2";
            // 
            // Health
            // 
            this.Health.AutoSize = true;
            this.Health.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Health.Location = new System.Drawing.Point(807, 22);
            this.Health.Name = "Health";
            this.Health.Size = new System.Drawing.Size(87, 25);
            this.Health.TabIndex = 7;
            this.Health.Text = "Health:";
            // 
            // healthBar
            // 
            this.healthBar.Location = new System.Drawing.Point(889, 22);
            this.healthBar.Name = "healthBar";
            this.healthBar.Size = new System.Drawing.Size(292, 23);
            this.healthBar.TabIndex = 8;
            this.healthBar.Value = 100;
            // 
            // GameTimer
            // 
            this.GameTimer.Enabled = true;
            this.GameTimer.Interval = 20;
            this.GameTimer.Tick += new System.EventHandler(this.MainGameTimer);
            // 
            // shooter
            // 
            this.shooter.Image = global::Zombie_Shootout_Game.Properties.Resources.up;
            this.shooter.Location = new System.Drawing.Point(552, 675);
            this.shooter.Name = "shooter";
            this.shooter.Size = new System.Drawing.Size(71, 100);
            this.shooter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.shooter.TabIndex = 9;
            this.shooter.TabStop = false;
            // 
            // HighScore
            // 
            this.HighScore.AutoSize = true;
            this.HighScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HighScore.Location = new System.Drawing.Point(-5, 764);
            this.HighScore.Name = "HighScore";
            this.HighScore.Size = new System.Drawing.Size(135, 25);
            this.HighScore.TabIndex = 14;
            this.HighScore.Text = "HighScore: ";
            // 
            // Level_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1200, 787);
            this.Controls.Add(this.HighScore);
            this.Controls.Add(this.shooter);
            this.Controls.Add(this.healthBar);
            this.Controls.Add(this.Health);
            this.Controls.Add(this.Stage_2);
            this.Controls.Add(this.Kills);
            this.Controls.Add(this.Ammo);
            this.Name = "Level_2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Level_2";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyisDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyisUp);
            ((System.ComponentModel.ISupportInitialize)(this.shooter)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Ammo;
        private System.Windows.Forms.Label Kills;
        private System.Windows.Forms.Label Stage_2;
        private System.Windows.Forms.Label Health;
        private System.Windows.Forms.ProgressBar healthBar;
        private System.Windows.Forms.Timer GameTimer;
        private System.Windows.Forms.PictureBox shooter;
        private System.Windows.Forms.Label HighScore;
    }
}