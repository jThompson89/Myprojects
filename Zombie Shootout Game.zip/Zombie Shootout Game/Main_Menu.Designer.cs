﻿namespace Zombie_Shootout_Game
{
    partial class Main_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.Exit_btn = new System.Windows.Forms.Button();
            this.Start_btn = new System.Windows.Forms.Button();
            this.Title_image = new System.Windows.Forms.PictureBox();
            this.Title_image1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Title_image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Title_image1)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.Location = new System.Drawing.Point(176, 48);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(404, 39);
            this.Title.TabIndex = 0;
            this.Title.Text = "Zombie Shootout Game";
            // 
            // Exit_btn
            // 
            this.Exit_btn.BackColor = System.Drawing.Color.Transparent;
            this.Exit_btn.BackgroundImage = global::Zombie_Shootout_Game.Properties.Resources.Exit;
            this.Exit_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Exit_btn.Location = new System.Drawing.Point(237, 278);
            this.Exit_btn.Name = "Exit_btn";
            this.Exit_btn.Size = new System.Drawing.Size(306, 112);
            this.Exit_btn.TabIndex = 2;
            this.Exit_btn.UseVisualStyleBackColor = false;
            this.Exit_btn.Click += new System.EventHandler(this.ExitGame_btn);
            // 
            // Start_btn
            // 
            this.Start_btn.BackColor = System.Drawing.Color.Gray;
            this.Start_btn.BackgroundImage = global::Zombie_Shootout_Game.Properties.Resources.start_normal;
            this.Start_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Start_btn.Location = new System.Drawing.Point(237, 124);
            this.Start_btn.Name = "Start_btn";
            this.Start_btn.Size = new System.Drawing.Size(306, 112);
            this.Start_btn.TabIndex = 1;
            this.Start_btn.UseVisualStyleBackColor = false;
            this.Start_btn.Click += new System.EventHandler(this.LoadGame);
            // 
            // Title_image
            // 
            this.Title_image.Image = global::Zombie_Shootout_Game.Properties.Resources.right;
            this.Title_image.Location = new System.Drawing.Point(12, 184);
            this.Title_image.Name = "Title_image";
            this.Title_image.Size = new System.Drawing.Size(150, 129);
            this.Title_image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Title_image.TabIndex = 3;
            this.Title_image.TabStop = false;
            // 
            // Title_image1
            // 
            this.Title_image1.Image = global::Zombie_Shootout_Game.Properties.Resources.zleft;
            this.Title_image1.Location = new System.Drawing.Point(623, 184);
            this.Title_image1.Name = "Title_image1";
            this.Title_image1.Size = new System.Drawing.Size(150, 129);
            this.Title_image1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Title_image1.TabIndex = 4;
            this.Title_image1.TabStop = false;
            // 
            // Main_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Title_image1);
            this.Controls.Add(this.Title_image);
            this.Controls.Add(this.Exit_btn);
            this.Controls.Add(this.Start_btn);
            this.Controls.Add(this.Title);
            this.Name = "Main_Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main_Menu";
            this.Load += new System.EventHandler(this.Main_Menu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Title_image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Title_image1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Button Start_btn;
        private System.Windows.Forms.Button Exit_btn;
        private System.Windows.Forms.PictureBox Title_image;
        private System.Windows.Forms.PictureBox Title_image1;
    }
}