﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace Zombie_Shootout_Game
{
    internal class HotShells
    {
        public string direction;
        public int bulletLeft;
        public int bulletTop;

        public int bulletLeft2;
        public int bulletTop2;

        public int bulletLeft3;
        public int bulletTop3;

        private int speed = 20;
       
        private PictureBox bullet = new PictureBox();
        private Timer bulletTimer = new Timer();

        private PictureBox bullet2 = new PictureBox();
        private Timer bulletTimer2 = new Timer();

        private PictureBox bullet3 = new PictureBox();
        private Timer bulletTimer3 = new Timer();

        WindowsMediaPlayer player = new WindowsMediaPlayer();

        public void MakeHotShells(Form form)
        {

            bullet.Image = Properties.Resources.hotshellup;
            bullet.Size = new Size(100, 100);
            bullet.Tag = "hotshells";
            bullet.Left = bulletLeft;
            bullet.Top = bulletTop;
            bullet.BringToFront();

            form.Controls.Add(bullet);


            bulletTimer.Interval = speed;
            bulletTimer.Tick += new EventHandler(HotShellsTimerEvent);
            bulletTimer.Start();

            bullet2.Image = Properties.Resources.hotshellup;
            bullet2.Size = new Size(100, 100);
            bullet2.Tag = "hotshells";
            bullet2.Left = bulletLeft;
            bullet2.Top = bulletTop;
            bullet2.BringToFront();

            form.Controls.Add(bullet);


            bulletTimer2.Interval = speed;
            bulletTimer2.Tick += new EventHandler(HotShellsTimerEvent);
            bulletTimer2.Start();

            bullet3.Image = Properties.Resources.hotshellup;
            bullet3.Size = new Size(100, 100);
            bullet3.Tag = "hotshells";
            bullet3.Left = bulletLeft;
            bullet3.Top = bulletTop;
            bullet3.BringToFront();

            form.Controls.Add(bullet);


            bulletTimer3.Interval = speed;
            bulletTimer3.Tick += new EventHandler(HotShellsTimerEvent);
            bulletTimer3.Start();
        }

        private void HotShellsTimerEvent(object sender, EventArgs e)
        {

            if (direction == "left")
            {
                bullet.Left -= speed;
                bullet.Image = Properties.Resources.hotshellleft;

            }

            if (direction == "right")
            {
                bullet.Left += speed;
                bullet.Image = Properties.Resources.hotshellright;
            }

            if (direction == "up")
            {
                bullet.Top -= speed;
                bullet.Image = Properties.Resources.hotshellup;

            }

            if (direction == "down")
            {
                bullet.Top += speed;
                bullet.Image = Properties.Resources.hotshelldown;

            }



            if (bullet.Left < 10 || bullet.Left > 1123 || bullet.Top < 10 || bullet.Top > 860)
            {
                bulletTimer.Stop();
                bulletTimer.Dispose();
                bullet.Dispose();
                bulletTimer = null;
                bullet = null;
            }

            if (direction == "left")
            {
                bullet2.Left -= speed;
                bullet2.Image = Properties.Resources.hotshellleft;

            }

            if (direction == "right")
            {
                bullet2.Left += speed;
                bullet2.Image = Properties.Resources.hotshellright;
            }

            if (direction == "up")
            {
                bullet2.Top -= speed;
                bullet2.Image = Properties.Resources.hotshellup;

            }

            if (direction == "down")
            {
                bullet2.Top += speed;
                bullet2.Image = Properties.Resources.hotshelldown;

            }



            if (bullet2.Left < 10 || bullet2.Left > 1123 || bullet2.Top < 10 || bullet2.Top > 860)
            {
                bulletTimer2.Stop();
                bulletTimer2.Dispose();
                bullet2.Dispose();
                bulletTimer2 = null;
                bullet2 = null;
            }


            if (direction == "left")
            {
                bullet3.Left -= speed;
                bullet3.Image = Properties.Resources.hotshellleft;

            }

            if (direction == "right")
            {
                bullet3.Left += speed;
                bullet3.Image = Properties.Resources.hotshellright;
            }

            if (direction == "up")
            {
                bullet3.Top -= speed;
                bullet3.Image = Properties.Resources.hotshellup;

            }

            if (direction == "down")
            {
                bullet3.Top += speed;
                bullet3.Image = Properties.Resources.hotshelldown;

            }



            if (bullet3.Left < 10 || bullet3.Left > 1123 || bullet3.Top < 10 || bullet3.Top > 860)
            {
                bulletTimer3.Stop();
                bulletTimer3.Dispose();
                bullet3.Dispose();
                bulletTimer3 = null;
                bullet3 = null;
            }
        }
    }
}
