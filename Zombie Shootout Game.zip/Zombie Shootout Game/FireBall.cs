﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace Zombie_Shootout_Game
{
    internal class FireBall
    {
        public string direction;
        public int fireballLeft;
        public int fireballTop;

        public int fireballLeft2;
        public int fireballTop2;

        public int fireballLeft3;
        public int fireballTop3;


        private int speed = 20;
        private int speed2 = 20;

        private PictureBox bullet = new PictureBox();
        private Timer bulletTimer = new Timer();

        private PictureBox bullet2 = new PictureBox();
        private Timer bulletTimer2 = new Timer();

        private PictureBox bullet3 = new PictureBox();
        private Timer bulletTimer3 = new Timer();

        WindowsMediaPlayer player = new WindowsMediaPlayer();


        public void MakeFireBall(Form form)
        {

            bullet.Image = Properties.Resources.shotRed;
            bullet.Size = new Size(100, 100);
            bullet.Tag = "fireball";
            bullet.Left = fireballLeft;
            bullet.Top = fireballTop;
            bullet.BringToFront();

            form.Controls.Add(bullet);

            bullet2.Image = Properties.Resources.shotRed;
            bullet2.Size = new Size(100, 100);
            bullet2.Tag = "fireball";
            bullet2.Left = fireballLeft;
            bullet2.Top = fireballTop;
            bullet2.BringToFront();

            form.Controls.Add(bullet);

            bullet3.Image = Properties.Resources.shotRed;
            bullet3.Size = new Size(100, 100);
            bullet3.Tag = "fireball";
            bullet3.Left = fireballLeft;
            bullet3.Top = fireballTop;
            bullet3.BringToFront();

            form.Controls.Add(bullet);


            bulletTimer.Interval = speed;
            bulletTimer.Tick += new EventHandler(FireBallTimerEvent);
            bulletTimer.Start();
        }

        private void FireBallTimerEvent(object sender, EventArgs e)
        {

            if (direction == "left")
            {
                bullet.Left -= speed;
                bullet.Image = Properties.Resources.shotRedleft;

            }

            if (direction == "right")
            {
                bullet.Left += speed;
                bullet.Image = Properties.Resources.shotRedright;
            }

            if (direction == "up")
            {
                bullet.Top -= speed;
                bullet.Image = Properties.Resources.shotRed;

            }

            if (direction == "down")
            {
                bullet.Top += speed;
                bullet.Image = Properties.Resources.shotReddown;

            }



            if (bullet.Left < 10 || bullet.Left > 1123 || bullet.Top < 10 || bullet.Top > 860)
            {
                bulletTimer.Stop();
                bulletTimer.Dispose();
                bullet.Dispose();
                bulletTimer = null;
                bullet = null;
            }

            if (direction == "left")
            {
                bullet2.Left -= speed;
                bullet2.Image = Properties.Resources.shotRedleft;

            }

            if (direction == "right")
            {
                bullet2.Left += speed;
                bullet2.Image = Properties.Resources.shotRedright;
            }

            if (direction == "up")
            {
                bullet2.Top -= speed;
                bullet2.Image = Properties.Resources.shotRed;

            }

            if (direction == "down")
            {
                bullet2.Top += speed;
                bullet2.Image = Properties.Resources.shotReddown;

            }

            if (bullet2.Left < 10 || bullet2.Left > 1123 || bullet2.Top < 10 || bullet2.Top > 860)
            {
                bulletTimer2.Stop();
                bulletTimer2.Dispose();
                bullet2.Dispose();
                bulletTimer2 = null;
                bullet2 = null;
            }
        }
    }
}

