﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace Zombie_Shootout_Game
{
    internal class Torch
    {
        public string direction;
        public int torchLeft;
        public int torchTop;

        public int torchLeft2;
        public int torchTop2;

        public int torchLeft3;
        public int torchTop3;


        private int speed = 20;
        private int speed2 = 20;

        private PictureBox torch = new PictureBox();
        private Timer torchTimer = new Timer();

        private PictureBox torch2 = new PictureBox();
        private Timer torchTimer2 = new Timer();

        private PictureBox torch3 = new PictureBox();
        private Timer torchTimer3 = new Timer();

        WindowsMediaPlayer player = new WindowsMediaPlayer();

        public void MakeTorch(Form form)
        {

            torch.Image = Properties.Resources.shotOrange;
            torch.Size = new Size(100, 100);
            torch.Tag = "torch";
            torch.Left = torchLeft;
            torch.Top = torchTop;
            torch.BringToFront();

            form.Controls.Add(torch);

            torch2.Image = Properties.Resources.shotOrange;
            torch2.Size = new Size(100, 100);
            torch2.Tag = "torch";
            torch2.Left = torchLeft;
            torch2.Top = torchTop;
            torch2.BringToFront();

            form.Controls.Add(torch);

            torch3.Image = Properties.Resources.shotOrange;
            torch3.Size = new Size(100, 100);
            torch3.Tag = "torch";
            torch3.Left = torchLeft;
            torch3.Top = torchTop;
            torch3.BringToFront();

            form.Controls.Add(torch);


            torchTimer.Interval = speed;
            torchTimer.Tick += new EventHandler(TorchTimerEvent);
            torchTimer.Start();
        }

        private void TorchTimerEvent(object sender, EventArgs e)
        {

            if (direction == "left")
            {
                torch.Left -= speed;
                torch.Image = Properties.Resources.shotOrangeleft;

            }

            if (direction == "right")
            {
                torch.Left += speed;
                torch.Image = Properties.Resources.shotOrangeright;
            }

            if (direction == "up")
            {
                torch.Top -= speed;
                torch.Image = Properties.Resources.shotOrange;

            }

            if (direction == "down")
            {
                torch.Top += speed;
                torch.Image = Properties.Resources.shotOrangedown;

            }



            if (torch.Left < 10 || torch.Left > 1123 || torch.Top < 10 || torch.Top > 860)
            {
                torchTimer.Stop();
                torchTimer.Dispose();
                torch.Dispose();
                torchTimer = null;
                torch = null;
            }

            if (direction == "left")
            {
                torch2.Left -= speed;
                torch2.Image = Properties.Resources.shotOrangeleft;

            }

            if (direction == "right")
            {
                torch2.Left += speed;
                torch2.Image = Properties.Resources.shotOrangeright;
            }

            if (direction == "up")
            {
                torch2.Top -= speed;
                torch2.Image = Properties.Resources.shotOrange;

            }

            if (direction == "down")
            {
                torch2.Top += speed;
                torch2.Image = Properties.Resources.shotOrangedown;

            }

            if (torch2.Left < 10 || torch2.Left > 1123 || torch2.Top < 10 || torch2.Top > 860)
            {
                torchTimer2.Stop();
                torchTimer2.Dispose();
                torch2.Dispose();
                torchTimer2 = null;
                torch2 = null;
            }
        }
    }
}

